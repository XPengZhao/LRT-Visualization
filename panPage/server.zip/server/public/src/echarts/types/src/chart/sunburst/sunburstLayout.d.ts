import GlobalModel from '../../model/Global';
import ExtensionAPI from '../../core/ExtensionAPI';
export default function sunburstLayout(seriesType: 'sunburst', ecModel: GlobalModel, api: ExtensionAPI): void;
