import { StageHandler } from '../../util/types';
declare const linesLayout: StageHandler;
export default linesLayout;
