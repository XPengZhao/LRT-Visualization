import { AxisBaseOption } from './axisCommonTypes';
declare const _default: {
    category: AxisBaseOption;
    value: AxisBaseOption;
    time: AxisBaseOption;
    log: AxisBaseOption;
};
export default _default;
