import GlobalModel from '../../model/Global';
export default function sunburstVisual(ecModel: GlobalModel): void;
