import GraphSeriesModel from './GraphSeries';
import { GraphNode } from '../../data/Graph';
export declare function getNodeGlobalScale(seriesModel: GraphSeriesModel): number;
export declare function getSymbolSize(node: GraphNode): number;
