import { GeoJSONRegion } from '../Region';
export default function fixTextCoords(mapType: string, region: GeoJSONRegion): void;
