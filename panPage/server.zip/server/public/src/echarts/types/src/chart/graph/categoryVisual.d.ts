import GlobalModel from '../../model/Global';
export default function categoryVisual(ecModel: GlobalModel): void;
