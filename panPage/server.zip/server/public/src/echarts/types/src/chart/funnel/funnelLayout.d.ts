import ExtensionAPI from '../../core/ExtensionAPI';
import GlobalModel from '../../model/Global';
export default function funnelLayout(ecModel: GlobalModel, api: ExtensionAPI): void;
