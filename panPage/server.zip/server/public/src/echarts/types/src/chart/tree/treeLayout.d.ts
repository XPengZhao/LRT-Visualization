import GlobalModel from '../../model/Global';
import ExtensionAPI from '../../core/ExtensionAPI';
export default function treeLayout(ecModel: GlobalModel, api: ExtensionAPI): void;
