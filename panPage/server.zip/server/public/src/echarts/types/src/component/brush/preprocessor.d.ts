import { ECUnitOption } from '../../util/types';
export default function brushPreprocessor(option: ECUnitOption, isNew: boolean): void;
