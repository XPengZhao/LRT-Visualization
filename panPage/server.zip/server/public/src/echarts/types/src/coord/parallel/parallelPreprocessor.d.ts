import { ECUnitOption } from '../../util/types';
export default function parallelPreprocessor(option: ECUnitOption): void;
