import { EChartsExtensionInstallRegisters } from '../../extension';
export default function installScrollableLegendAction(registers: EChartsExtensionInstallRegisters): void;
