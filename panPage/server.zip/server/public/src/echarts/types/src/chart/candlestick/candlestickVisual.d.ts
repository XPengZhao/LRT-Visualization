import { StageHandler } from '../../util/types';
declare const candlestickVisual: StageHandler;
export default candlestickVisual;
