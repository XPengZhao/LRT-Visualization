import { EChartsExtensionInstallRegisters } from '../../extension';
export declare function install(registers: EChartsExtensionInstallRegisters): void;
