import TreemapSeriesModel from './TreemapSeries';
declare const _default: {
    seriesType: string;
    reset(seriesModel: TreemapSeriesModel): void;
};
export default _default;
