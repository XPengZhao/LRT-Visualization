import GlobalModel from '../../model/Global';
export default function treeVisual(ecModel: GlobalModel): void;
