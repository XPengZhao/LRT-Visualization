import { EChartsExtensionInstallRegisters } from '../../extension';
export declare const ROOT_TO_NODE_ACTION = "sunburstRootToNode";
export declare function installSunburstAction(registers: EChartsExtensionInstallRegisters): void;
