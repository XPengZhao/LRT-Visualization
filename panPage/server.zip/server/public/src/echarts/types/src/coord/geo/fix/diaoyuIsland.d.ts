import { GeoJSONRegion } from '../Region';
export default function fixDiaoyuIsland(mapType: string, region: GeoJSONRegion): void;
