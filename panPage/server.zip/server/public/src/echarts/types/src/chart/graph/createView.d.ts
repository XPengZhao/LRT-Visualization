import View from '../../coord/View';
import ExtensionAPI from '../../core/ExtensionAPI';
import GlobalModel from '../../model/Global';
export default function createViewCoordSys(ecModel: GlobalModel, api: ExtensionAPI): View[];
