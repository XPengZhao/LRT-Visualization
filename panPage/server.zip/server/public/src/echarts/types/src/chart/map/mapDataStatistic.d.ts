import GlobalModel from '../../model/Global';
export default function mapDataStatistic(ecModel: GlobalModel): void;
