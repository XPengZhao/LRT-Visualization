import { EChartsExtensionInstallRegisters } from '../../extension';
export default function installCommon(registers: EChartsExtensionInstallRegisters): void;
