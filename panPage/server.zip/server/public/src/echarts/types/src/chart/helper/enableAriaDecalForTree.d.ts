import SeriesModel from '../../model/Series';
export default function enableAriaDecalForTree(seriesModel: SeriesModel): void;
