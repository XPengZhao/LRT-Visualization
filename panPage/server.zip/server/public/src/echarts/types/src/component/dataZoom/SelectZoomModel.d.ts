import DataZoomModel from './DataZoomModel';
declare class SelectDataZoomModel extends DataZoomModel {
    static type: string;
    type: string;
}
export default SelectDataZoomModel;
