import GlobalModel from '../../model/Global';
export default function graphCircularLayout(ecModel: GlobalModel): void;
