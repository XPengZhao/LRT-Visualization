import { GeoJSONRegion } from '../Region';
export default function fixGeoCoords(mapType: string, region: GeoJSONRegion): void;
