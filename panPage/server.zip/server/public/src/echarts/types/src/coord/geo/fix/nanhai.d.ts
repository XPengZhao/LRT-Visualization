import { GeoJSONRegion } from '../Region';
export default function fixNanhai(mapType: string, regions: GeoJSONRegion[]): void;
