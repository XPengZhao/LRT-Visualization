import { EChartsExtensionInstallRegisters } from '../../extension';
export default function installDataZoomAction(registers: EChartsExtensionInstallRegisters): void;
