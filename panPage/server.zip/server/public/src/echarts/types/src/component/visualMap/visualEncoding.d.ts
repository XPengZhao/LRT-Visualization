import { StageHandler } from '../../util/types';
export declare const visualMapEncodingHandlers: StageHandler[];
