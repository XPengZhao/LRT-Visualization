import { StageHandler } from '../../util/types';
declare const dataZoomProcessor: StageHandler;
export default dataZoomProcessor;
