import GlobalModel from '../../model/Global';
export default function mapSymbolLayout(ecModel: GlobalModel): void;
