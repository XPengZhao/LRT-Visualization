import GlobalModel from '../../model/Global';
import ExtensionAPI from '../../core/ExtensionAPI';
export default function boxplotVisual(ecModel: GlobalModel, api: ExtensionAPI): void;
