import PieSeriesModel from './PieSeries';
export default function pieLabelLayout(seriesModel: PieSeriesModel): void;
