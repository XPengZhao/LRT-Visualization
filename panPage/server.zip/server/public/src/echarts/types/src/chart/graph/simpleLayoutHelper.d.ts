import GraphSeriesModel from './GraphSeries';
import Graph from '../../data/Graph';
export declare function simpleLayout(seriesModel: GraphSeriesModel): void;
export declare function simpleLayoutEdge(graph: Graph, seriesModel: GraphSeriesModel): void;
