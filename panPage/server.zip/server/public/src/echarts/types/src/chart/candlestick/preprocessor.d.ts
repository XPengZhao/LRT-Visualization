import { ECUnitOption } from '../../util/types';
export default function candlestickPreprocessor(option: ECUnitOption): void;
