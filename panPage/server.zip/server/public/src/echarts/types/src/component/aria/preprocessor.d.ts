import { ECUnitOption, AriaOptionMixin } from '../../util/types';
export default function ariaPreprocessor(option: ECUnitOption & AriaOptionMixin): void;
