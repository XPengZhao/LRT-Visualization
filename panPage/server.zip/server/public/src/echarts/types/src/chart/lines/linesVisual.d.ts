import { StageHandler } from '../../util/types';
declare const linesVisual: StageHandler;
export default linesVisual;
