import ExtensionAPI from '../../core/ExtensionAPI';
import GlobalModel from '../../model/Global';
export default function sankeyLayout(ecModel: GlobalModel, api: ExtensionAPI): void;
