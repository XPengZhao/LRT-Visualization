import { StageHandler } from '../../util/types';
declare const parallelVisual: StageHandler;
export default parallelVisual;
