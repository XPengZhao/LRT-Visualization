export declare function parse(xml: any): {
    nodes: {
        id: any;
        name: any;
        itemStyle: {
            normal: {};
        };
    }[];
    links: {
        id: any;
        name: any;
        source: any;
        target: any;
        lineStyle: {
            normal: {};
        };
    }[];
};
