import './BMapModel';
import './BMapView';
export declare const version = "1.0.0";
